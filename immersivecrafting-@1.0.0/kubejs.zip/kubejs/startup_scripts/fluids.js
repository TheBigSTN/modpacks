StartupEvents.registry('fluid', event => {
    event.create('liquid_redstone')
        .thinTexture(0xAA0000)
        .bucketColor(0xAA0000)
        .displayName('Liquid Redstone')
})