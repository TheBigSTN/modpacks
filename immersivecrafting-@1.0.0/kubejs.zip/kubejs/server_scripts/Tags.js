ServerEvents.tags("item", event => {
    event.add("createbigcannons:ingot_bronze","create:brass")
    event.add("createbigcannons:block_bronze","create:brass_block")
    event.add("sliceanddice:allowed_tools","minecraft:shears")
})